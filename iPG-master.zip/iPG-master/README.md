iPG
===

iPG is a basic Y-Combinator interview simulator which asks general
questions about you and your company, akin to the questions in which you
may be asked in a real Y-Combinator, or any incubator/investor, interview.

iPG was written by James Cunningham and Colin Hayhurst for their
Y-Combinator interview with [GoScale](https://goscale.com).
